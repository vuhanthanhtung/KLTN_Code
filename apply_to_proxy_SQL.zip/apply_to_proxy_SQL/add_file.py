import sys
import os
import subprocess

def scan_directory(directory):
        listfile = []
        for r,d,f in os.walk(directory):
                for files in f:
                        if ".php" or ".txt" in files:
                                listfile.append(os.path.join(r,files))
        return listfile
def arrange(array):
	for i in range(0,len(array)):
		for j in range(0,len(array)):
			if (len(array[i])>len(array[j])):
				tmp = array[i]
				array[i]=array[j]
				array[j]= tmp	
	return array


directory = "/opt/PHP"
listfile= scan_directory(directory)
array = []
for files in listfile:
	f = open(files,"r").readlines()
	for j in f:
		array.append(j.strip())
count =1
array=arrange(array)
print "Your rules were added to ProxySQL successfully"
for i in array:
	string="\""+ i.strip() + "\""
	subprocess.Popen('/usr/bin/bash /opt/script/utilmate/apply_to_proxy_sql.sh %s %s' %(string, count),shell=True)
	count= count +1
	

