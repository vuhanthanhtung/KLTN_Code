#!/bin/bash
query=$1
rule_id=$2


mysql -u admin -padmin -h127.0.0.1 -P6032 -e "insert into mysql_query_rules (rule_id,active,username,match_digest,destination_hostgroup,apply,error_msg) values (10000,1,'imba','.',1,1,'Not Allowed');" > /dev/null 2>&1

if [[ `echo $query | grep "'"` != "" ]]
then
	mysql -u admin -padmin -h127.0.0.1 -P6032 -e "insert into mysql_query_rules (rule_id,active,username,match_digest,destination_hostgroup,apply) values ($rule_id,1,'imba',\"$query\",1,1);" > /dev/null 2>&1
else
	mysql -u admin -padmin -h127.0.0.1 -P6032 -e "insert into mysql_query_rules (rule_id,active,username,match_digest,destination_hostgroup,apply) values ($rule_id,1,'imba','$query',1,1);" > /dev/null 2>&1
fi
mysql -u admin -padmin -h127.0.0.1 -P6032 -e "load mysql query rules to runtime;" > /dev/null 2>&1

