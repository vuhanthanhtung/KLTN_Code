#!/bin/bash
file="$1"
for i in {0..50..1}
do
`mysql -u imba -pimba -h192.168.229.131 -P6033 -e "use databasefirewall;select * from users where username='admin' and password='admin'"`
`mysql -u admin -padmin -h127.0.0.1 -P6032 -e "SELECT sum_time FROM stats_mysql_query_digest ORDER BY sum_time" | grep -v "sum_time"` >> $file
`mysql -u admin -padmin -h127.0.0.1 -P6032 -e "load mysql query rules to runtime"`
done

