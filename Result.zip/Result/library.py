import os
import glob
import library
def lower_string(string):
	result = ""
	result = string.lower()
	return result

def scan_select(string):
    	result=""
    	string=lower_string(string)
        if("\"select\"" in string):
            return result
        if("\'select\'" in string):
            return result

    	if ("\"select" in string):
		tmp_str1=string.split("\"select")[1]
        	tmp_str=tmp_str1.split("\"")[0]
        	tmp_str="select"+tmp_str
        	result=tmp_str
	if ("\'select" in string):
        	tmp_str1=string.split("\'select")[1]
        	tmp_str=tmp_str1.split("\'")[0]
        	tmp_str="select"+tmp_str
        	result=tmp_str
    	return result

def scan_insert(string):
    	result=""
    	string=lower_string(string)
        if("\"insert\"" in string):
            return result
        if("\'insert\'" in string):
            return result

    	if("\"insert" in string):
        	tmp_str1=string.split("\"insert")[1]
        	tmp_str=tmp_str1.split("\"")[0]
        	tmp_str="insert"+tmp_str
        	result=tmp_str
    	if ("\'insert" in string):
        	tmp_str1=string.split("\'insert")[1]
        	tmp_str=tmp_str1.split("\'")[0]
        	tmp_str="insert"+tmp_str
        	result=tmp_str
    	return result

def scan_update(string):
    	result=""
    	string=lower_string(string)
        if("\"update\"" in string):
            return result
        if("\'update\'" in string):
            return result
    	if("\"update" in string):
        	tmp_str1=string.split("\"update")[1]
        	tmp_str=tmp_str1.split("\"")[0]
        	tmp_str="update"+tmp_str
        	result=tmp_str
    	if ("\'update" in string):
        	tmp_str1=string.split("\'update")[1]
        	tmp_str=tmp_str1.split("\'")[0]
        	tmp_str="update"+tmp_str
        	result=tmp_str
    	return result

def Del_space(string):
	result = ""
    	result = string.strip()
	return result

def Del_all_space(string):
	result = ""
    	result = string.replace(" ","")
	return result

def Replace_spaces_to_1_space(string):
	result = ""
    	while ("  " in string):
        	string=string.replace("  "," ")
    	result = string
	return result

def split_multi_query(string):
	result = []
    	result = Del_space(string).split(";")
	return result

#Co chinh sua 1 chut trong ham nay
def Del_comment(string):
	result = ""
    	result = Replace_spaces_to_1_space(string)
    	if "//" in Del_space(result)[0:2]:
		result = ""
        	return result
    	if "; //" in Del_space(result):
        	result=result.split("; //")[0]
        	result=result+";"
        	return result
    	if ";//" in Del_space(result):
        	result=result.split(";//")[0]
        	result=result+";"
        	return result
    	return result

def Del_block_comment(string):
	result = string
        if ("/*" in string) and ("*/" in string):
            	result = ""
        return result

def Del_html(string):
    	result=""
    	a = Del_all_space(string)
    	if (a[0] == "<"):
        	return result
    	result = string
	return result

def check_sub_comma(string):
    	flag = 0
    	string = Del_space(string)
    	if (string[-1]!=";") and (("public function" not in string) and ("*/" not in string)):
        	flag = 1
    	return flag

def check_kep_don(string):
    	flag = 0
    	if ( "})" in string.strip()):
        	flag = 1
    	return flag

#Co chinh sua 1 chut o ham nay
def Del_kep(string):
	flag = 0
    	if ("})" in string):
        	return flag
    	if ("{" in string) or ("}" in string):
        	flag = 1
    	return flag

def get_name_function(string):
    	result = ""
    	if ( "public function" in string ):
        	result = string.split("function")[1]
    	if ( "public static function" in string ):
        	result = string.split("function")[1]
    	result = result.replace(";", " ")
	result = result.split("{")[0]
    	return result.strip()

def scan_directory(directory):
    	listfile = []
    	for r,d,f in os.walk(directory):
        	for files in f:
            		if ".php" or ".txt" in files:
                		listfile.append(os.path.join(r,files))
    	return listfile

def write_files(file, list):
	with open(file, "w+") as f:
		for i in list:
			f.write(i+"\n")

def read_files(file):
	with open(file, "r") as f:
		lines = f.readlines()
	return lines

def write_files_append(file, list):
        with open(file, "a+") as f:
                for i in list:
                        f.write(i+"\n")

def replace(string, model_name):
	result = string
	model = "(new " + model_name + ")->"
	if "$this->" in string:
		result = string.replace("$this->", model)
	if "self::" in string:
		result = string.replace("self", model_name)
	return result

def get_model_name(list):
	flag = 0
	model_name = ""
	for i in list:
		if "extends model" in i.lower():
	                model_name = i.split("class")[1].strip()
	                model_name = model_name.split("extends")[0].strip()
			flag = 1
			return model_name, flag
	return model_name.strip(), flag

def route(string, method):
	result = []
	method = "route::" + method
	if method in string.lower():
		tmp = string.lower().split(method)[1]
		tmp = tmp.split(",")
		url = tmp[0]
		for j in tmp:
			if "@" not in j:
				continue
			if "@" in j :
				if ("=>" in j):
					j=j.split("=>")[1]
				if (")" not in j):
					j=j+")"
				if (";" in j):
					j=j[:-2]
			result.append(url+j)
	return result

def get_function(string):
    	result = ""
    	if ( "public function" in string ):
        	result = string
    	if ("public static function" in string):
        	result = string
    	return result.strip()

#Co chinh sua cho nay, them break
def get_query(string):
	result = ""
	model_file = read_files("sub_folder/model.txt")
	for i in range(0,len(model_file)):
		model_file[i]=model_file[i].replace("\n","")
	for i in model_file:
		tmp= i+"::"
		if (tmp in string):
			result = string
			break
		tmp= "new "+i
		if (tmp in string):
			result = string
			break
	return result.strip()

def format_string(string):
	result = []
	lines = read_files("sub_folder/model.txt")
	if ("=>" in string):
		tmp = string.split("=>")
		for i in tmp:
			for j in lines:
				if ("(new "+j.strip() in i) or (j.strip()+"::" in i):
					tmp1=i.split(",")
					tmp2=""
					for j in range(0,len(tmp1)-1):
						if j==0:
							tmp2=tmp1[j]
						else: 
							tmp2=tmp2+","+tmp1[j]
					result.append(tmp2)
	else:
		for i in lines:
			tmp = "(new "+i.strip()
			if ( tmp in string ):
				string=string.split(tmp)[1]
				string=tmp+string
			tmp = i.strip() +"::"
			if ( tmp in string):
				string=string.split(tmp)[1]
				string= tmp+string
		result.append(string)
	return result

def get_url_from_route(string):
    	url=""
    	tmp = string.split(" ")
    	url = tmp[0].replace("(", "")
    	url = url.replace("'", "")
    	if ("/" in url):
        	url = url.replace("/","@")
    	return  url.strip()

def get_controller_function_name(string):
    	controller_function_name=""
    	tmp = string.split(" ")
    	controller_function_name = tmp[1].split("')")[0]
    	controller_function_name = controller_function_name.replace("'", "")
    	return controller_function_name.lower().strip()

def get_controller_name(string):
    	controller_name=""
    	tmp = string.split("@")
    	controller_name = tmp[0]
    	if ("\\" in controller_name):
        	controller_name = controller_name.split("\\")[-1]
    	return controller_name.strip()

def get_function_name(string):
    	function_name=""
    	tmp = string.split("@")
    	function_name = tmp[1]
    	return function_name.strip()

#Co chinh sua 1 chut o ham nay
#def get_all_query_in_controller_function_file(directory, string):
def get_all_query_from_function(file, string):
    	result=[]
    	array = library.read_files(file)
    	for i in range(0,len(array)):
        	tmp = array[i].split("function")[-1].lower()
        	tmp = tmp.split("(")[0].strip()
        	if (tmp.lower().strip() == string.lower().strip()):
            		j=i+1
            		if (j < len(array)):
	                	for j in range(j,len(array)):
                    			if (("public function" in array[j]) or ("public static function" in array[j])):
                        			break
                    			else:
                        			result.append(array[j].strip())
    	return result

######################################################################
def get_value(string):
    	result=[]
    	if ( "(" in string) and (")" in string):
        	string=string.split("(")[1]
        	string=string.split(")")[0]
        	result=string.split(",")
    	return result
######################################################################
def get_array_variable(file,function_name):
    result = []
    array = library.read_files(file)
    for i in array:
        if ("public function" in i.strip().lower()) or ("public static function" in i.strip().lower()):
            if (function_name.strip().lower() in i.strip().lower()):
                result = library.get_value(i)
    return result


def replace_variables_to_values(array_variable,array_value,array_query):
    result = []
    if ( array_variable == []):
        result = array_query
        return result
    if ( array_value == []):
        result = array_query
        return result
    if ( array_query == []):
        return result
    for i in array_query:
        tmp = i
        for j in range(0,len(array_variable)):
            if ("$"+array_variable[j].strip() in i ):
                tmp = tmp.replace("$"+array_variable[j].strip(),array_value[j])
        result.append(tmp)
    return result

def Link(file_to_read):
    result = []
    model_function = library.read_files("sub_folder/model_function.txt")
    file_to_read = library.read_files(file_to_read)
    for i in file_to_read:
        flag = 0
        compare = ""
        if ("(new" in i.strip().lower()):
            compare = i.strip().split("(new")[1]
            compare = compare.split("(")[0]
            compare = "(new" + compare
        if ("::" in i.strip().lower()):
            compare = i.strip().split("(")[0]
        for j in model_function:
            model_name = j.split("->")[0]
            model_name = model_name[5:-1]
            function_name = j.split("->")[1]
            tmp = model_name.strip() + "::" + function_name.strip()
            if (j.strip() == compare.strip()) or (tmp.strip() == compare.strip()):
                flag = 1
                array_query = library.get_all_query_from_function("sub_folder/model/"+model_name.lower()+".txt",function_name)
                array_variable = get_array_variable("sub_folder/model/"+model_name.lower()+".txt",function_name)
                tmp = i.split("->"+function_name.strip())[-1]
                array_value = get_value(tmp)
                list = library.replace_variables_to_values(array_variable,array_value,array_query)
                if list != []:
                    for z in list:
                        result.append(z.strip().split(";")[0])
        if flag == 0:
            result.append(i.strip().split(";")[0])
    return result
#### testing
#a = Link("sub_folder/model/shopproduct.txt")
#for i in a:
#    print i 
def get_real_table_name(file):
    result = ""
    lines = library.read_files(file);
    for i in lines:
        if "$table" in i.strip():
            result = i.split("';")[0]
            result = result.split("'")[1]
            return result
    return result


##Input 1 list (cac dong trong file), Output 1 list
def format(lines):
	result = []
	string = ""
	for i in range(0,len(lines)):
		if (library.Del_space(lines[i]) ==""):
			continue
		if (library.Del_kep(lines[i]) == 1):
			if ("where" not in string) or ("if" in string) or (("where" not in lines[i]) and ("if" in lines[i])):
				lines[i]=lines[i].replace("{", ";")
				lines[i]=lines[i].replace("}", ";")
		tmp=library.Del_comment(lines[i])
		if (tmp == ""):
			continue
		else:
			lines[i]=tmp
		tmp=library.Del_html(lines[i])
		if (tmp == ""):
			continue
		else:
			lines[i]=tmp
		if (library.check_sub_comma(lines[i])==1):
			string=string + " " + library.Del_space(lines[i]).replace("\n"," ")
        	        continue
		else:
			string=string + " " + library.Del_space(lines[i]).replace("\n"," ")
			j=i+1
			while ( j < len(lines)):
				if ( lines[j].strip() != ""):
					break
				j=j+1
			if ( j< len(lines)):
				if (library.check_kep_don(lines[j])==1):
					continue
		result.append(string)
		string = ""
	return result
