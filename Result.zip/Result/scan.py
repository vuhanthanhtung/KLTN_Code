import library
import os
def get_variable(string):
    result=[]
    if ("$" in string):
        tmp = string.split("$")
        if ( len(tmp)>1):
            for i in range(1,len(tmp)):
                    tmp_1=tmp[i].split("'")[0]
                    tmp_1=tmp_1.split('"')[0]
                    result.append(tmp_1)
    if (":" in string):
        tmp = string.split(":")
        if (len(tmp)>1):
            for i in range(1,len(tmp)):
                if ("," in tmp[i]):
                    tmp_1=tmp[i].split(",")[0]
                    tmp_1=tmp_1.split(" ")[0]
                elif (")" in tmp[i]):
                    tmp_1=tmp[i].split(")")[0]
                    tmp_1=tmp_1.split(" ")[0]

                else:
                    tmp_1=tmp[i].split(" ")[0]
                result.append(tmp_1)
    return result
def get_value(string):
    result=[]
    array = string.replace("'"," ")
    array = array.replace('"',' ')
    array = library.Replace_spaces_to_1_space(array)
    array = array.split("= ")
    if (len(array)>1):
        for i in range(1,len(array)):
            if ("(.+)" in array[i]):
                continue
            tmp_1=array[i].split(" ")[0]
            result.append(tmp_1)

    return result

def replace_variable_to_questionaire(string):
    array = get_variable(string)
#    if ("\"" in string):
#        string=string.replace("\"","\\\"")
#    if ("\'" in string):
#        string=string.replace("\'","\\\'")
    if ("(" in string):
        string=string.replace("(","\(")
    if (")" in string):
        string=string.replace(")","\)")
    if ("*" in string):
        string=string.replace("*","\*")
    result =""
    for i in array:
        tmp = "'$"+i+"'"
        if tmp in string:
            string=string.replace(tmp,"(.+)")
        tmp = '"$'+i+'"'
        if tmp in string:
            string=string.replace(tmp,"(.+)")
        tmp = ":"+i
        if tmp in string:
            string=string.replace(tmp,"(.+)")
    result = string
    return result

def replace_value_to_questionaire(string):
    array = get_value(string)
    for i in array:
        tmp="'"+i+"'"
        if (tmp in string):
            string=string.replace(tmp,"(.+)")
        tmp= '"'+i+'"'
        if (tmp in string):
            string=string.replace(tmp,"(.+)")
    result = string
    return result
######
####

#str = ""
#listfile = []
#directory_to_read = "/var/www/html/basicwebsite"
#directory_to_write="sub_folder/PHP/"
def Scan_PHP(directory_to_read):
    str=""
    directory_to_write="sub_folder/PHP/"
    listfile = library.scan_directory(directory_to_read)
    for file in listfile:
        f = open(file,"r")
        file_to_write = directory_to_write + os.path.basename(f.name).lower().replace("txt","txt")
        result = []
        name= os.path.basename(f.name)
	f = library.read_files(file)
	for i in f:
		if (library.Del_space(i) ==""):
			continue
		tmp = library.Del_comment(i)
		if (tmp == ""):
			continue
		else:
			i = tmp
    		tmp = library.Del_html(i)
    		if (tmp == ""):
        		continue
    		else:
        		i=tmp
    		if (library.check_sub_comma(i)==1):
        		str = str + " " + library.Del_space(i).replace("\n"," ")
        		continue
    		else:
        		str = str + " " + library.Del_space(i).replace("\n"," ")
		if (str != ""):
        		array = library.split_multi_query(str)
    		if (len(array)!=1):
        		for j in array:
        	    		if (j!=""):
					j = library.Replace_spaces_to_1_space(j)
        	        		#if ("\" " in j):
        	            		#	j = j.replace("\" ","\"")
        	        		#if ("\' " in j):
        	            		#	j = j.replace("\' ","\'")
        	        		j = library.Del_space(j);
                                        #j=replace_variable_to_questionaire(j)
        	        		if(library.scan_select(j)!= ""):
                                                tmp_1= library.scan_select(j)
                                                print name+ "\t"+tmp_1
                                                tmp_1=replace_variable_to_questionaire(tmp_1)
                                                tmp_1=replace_value_to_questionaire(tmp_1)
                                                if (tmp_1.strip()[-1] !=")" and tmp_1.strip()[-1] != "'" and tmp_1.strip()[-1] != '"'):
                                                    tmp_1="(?i)(^"+tmp_1.strip()+"$)"
                                                else:
                                                    tmp_1="(?i)(^"+tmp_1.strip()+"\B$)"
        	            			result.append(tmp_1)
        	        		if(library.scan_insert(j)!= ""):
                                                tmp_1= library.scan_insert(j)
                                                print name+ "\t"+tmp_1
                                                tmp_1=replace_variable_to_questionaire(tmp_1)
                                                tmp_1=replace_value_to_questionaire(tmp_1)
                                                if (tmp_1.strip()[-1] !=")"):
                                                    tmp_1="(?i)(^"+tmp_1.strip()+"$)"
                                                else:
                                                    tmp_1="(?i)(^"+tmp_1.strip()+"\B$)"
                                                result.append(tmp_1)
					if(library.scan_update(j)!= ""):
                                                tmp_1= library.scan_update(j)
                                                print name+"\t"+tmp_1
                                                tmp_1=replace_variable_to_questionaire(tmp_1)
                                                tmp_1=replace_value_to_questionaire(tmp_1)
                                                if (tmp_1.strip()[-1] !=")"):
                                                    tmp_1="(?i)(^"+tmp_1.strip()+"$)"
                                                else:
                                                    tmp_1="(?i)(^"+tmp_1.strip()+"\B$)"
                                                result.append(tmp_1)
		str = ""
        library.write_files(file_to_write, result)
