import library
import os
def controller(directory):
    #directory="/root/laravel-ecommerce/app/Http/Controllers"
    controller_listfile = library.scan_directory(directory)
    for files in controller_listfile:
	list = []
	list_string = []
	f = open(files, "r")
	lines = f.readlines()
	name_file = "sub_folder/controller/" + os.path.basename(f.name).lower().replace("php","txt")
	list_string = library.format(lines)
	for string in list_string:
		result = ""
		result=library.get_function(string)
		if (result != ""):
			list.append(result)
		result=library.get_query(string)
		result = library.format_string(result)
		for z in result:
			if (z != ""):
				list.append(z)
	library.write_files(name_file, list)
