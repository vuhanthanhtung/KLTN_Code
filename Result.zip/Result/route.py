import library
def route(directory):
    #directory = "/root/laravel-ecommerce/routes"
    file = "sub_folder/route.txt"
    list = []
    listfile = library.scan_directory(directory)
    for files in listfile:
    	    f = library.read_files(files)
            for i in f:
		    result = library.route(i, "get")
        	    for j in result:
			    list.append(j)
		    result = library.route(i, "post")
		    for j in result:
			    list.append(j)

    library.write_files(file,list)
