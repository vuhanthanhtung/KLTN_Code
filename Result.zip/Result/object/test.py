import re
def get_value(string):
    result = []
    array= string.split(" ")
    for i in array:
        if ((i[0]=='"') and (i[-1]=='"')) or ((i[0]=="'") and (i[-1]=="'")):
            tmp=i.replace('"','').replace("'","").strip()
            result.append(tmp)
    return result

string ="select * from `information` where `isStudent` = 'Yes' and `Number` < '8000' order by `id` desc limit '2'"
a=get_value(string)
print a
