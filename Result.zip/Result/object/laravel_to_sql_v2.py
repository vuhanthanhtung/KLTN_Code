from collections import OrderedDict 
from query import query
import os
import sys
sys.path.append("../")
import library
############################## Xu ly chuoi sau khi lay duoc truy van
def get_variable_to_replace(string):
    result=[]
    if ("$" in string) and ("'$" not in string ) and ('"$' not in string):
        tmp = string.split("$")
        if ( len(tmp)>1):
            for i in range(1,len(tmp)):
                    tmp_1=tmp[i].split(" ")[0]
                    result.append(tmp_1)
    return result
def get_value_to_replace(string):
    result = []
    array= string.split(" ")
    for i in array:
        if ((i[0]=='"') and (i[-1]=='"')) or ((i[0]=="'") and (i[-1]=="'")):
            tmp=i.replace('"','').replace("'","").strip()
            result.append(tmp)
    return result
def replace_variable_value_to_questionaire(string):
    array = get_variable_to_replace(string)
#    if ("\"" in string):
#        string=string.replace("\"","\\\"")
#    if ("\'" in string):
#        string=string.replace("\'","\\\'")
    if ("(" in string):
        string=string.replace("(","\(")
    if (")" in string):
        string=string.replace(")","\)")
    if ("*" in string):
        string=string.replace("*","\*")
    result =""
    for i in array:
        tmp = "$"+i
        if tmp in string:
            string=string.replace(tmp,"(.+)")
            
    array = get_value_to_replace(string)
    if (array == ""):
        return result
    for i in array:
        tmp="'"+i+"'"
        if (tmp in string):
            string=string.replace(tmp,"(.+)")
        tmp= '"'+i+'"'
        if (tmp in string):
            string=string.replace(tmp,"(.+)")
    result = string
    return result

###############################
def get_value_in_parentheses(string):
    result = []
    string=string.replace("(","")
    string=string.replace(")","")
    array=string.split(",")
    result=array
    return result

def split_string_to_key_and_value(string,seq):
    dictionary= OrderedDict()
    if (string==""):
        return dictionary
    tmp = string.strip().split("(")
    key = tmp[0] + "["+str(seq)+"]"
    value = "(" + tmp[-1]
    dictionary[key.strip()]= value
    return dictionary

def string_array_dictionary(string):
    if ("::" in string):
        array = string.split("::")[1]
        array = array.split("->")
        dictionary=OrderedDict()
        for i in range(0,len(array)):
            tmp = split_string_to_key_and_value(array[i],i)
            dictionary.update(tmp.items())
    else:
        array = string.strip().split("->")[0]
        array = string.split(array+"->")[-1]
        array = array.split("->")
        dictionary=OrderedDict()
        for i in range(0,len(array)):
            tmp = split_string_to_key_and_value(array[i],i)
            dictionary.update(tmp.items())

    return dictionary
#### Get_query_type
def get_query_type(dictionary):
    result = "select"
    for i in range(0,len(dictionary)):
        if ("get"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            result = "select"
        if ("first"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            result = "select"
    return result

#### Get_Table
def get_table_name_for_sql(string,table_name=None):
    table_name_file="sub_folder/table.txt"
    f = library.read_files(table_name_file)
    result=""
    if ("::" in string):
        result=string.split("::")[0]
    if ("new" in string):
        result=string.split("new")[1]
        result=result.split(")->")[0]
    for i in f:
        model_name=i.strip().split("::")[0]
        table_name=i.strip().split("::")[1]
        if (result.strip() == model_name.strip()):
            return table_name
    result = "" 
    return result


#### Get_condition
def get_condition_for_sql(dictionary):
    result=""
    count=0
    for i in range(0,len(dictionary)):
        if ("where"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            if count != 0:
                result = result + " and "
            if len(tmp) > 2:
                result = result +"`"+tmp[0].strip().replace("'","").replace('"','')+"`" +" "+ tmp[1].strip().replace("'","").replace('"','')+" " +tmp[2].strip()
            if len(tmp) ==2:
                result = result +"`"+ tmp[0].replace("'","").replace('"','')+"`"+ " = " +tmp[1].strip()
            count = count + 1
        if ("orwhere"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            if count != 0:
                result = result + " or "
            if len(tmp) > 2:
                result = result +"`"+tmp[0].strip().replace("'","").replace('"','')+"`" +" "+ tmp[1].strip().replace("'","").replace('"','')+" " +tmp[2].strip()
            if len(tmp) ==2:
                result = result +"`"+ tmp[0].replace("'","").replace('"','')+"`"+ " = " +tmp[1].strip()
            count = count + 1
        if ("find"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            if count != 0:
                result = result + " and "
            result = result + "`id` = " +tmp[0]
    if (result ==""):
        result= None
    return result
#### Get_groupby
def get_groupby_for_sql(dictionary):
    count = 0
    result = ""
    for i in range(0,len(dictionary)):
        if ("groupby"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            if count !=0:
                result = result + " and "
            for j in range(0,len(tmp)):
                if (j==0):
                    result = result + tmp[j]
                if (j>0):
                    result = result + "," + tmp[j]
            count= count + 1
    if result == "":
        result = None
    return result

#### Get Orderby
def get_orderby_for_sql(dictionary):
    count = 0
    result = ""
    for i in range(0,len(dictionary)):
        if ("orderby"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            if count !=0:
                result = result + ", "
            for j in range(0,len(tmp)):
                if (j==0):
                    result = result + "`"+tmp[j].replace("'","").replace('"',"").strip()+"`"
                if ( j>0):
                    result = result + " " + tmp[j].replace("'","").replace('"',"").strip()
            count= count + 1
    if result == "":
        result = None
    return result

#### Get option of query
def get_option_of_query(dictionary):
    result = ""
    for i in range(0,len(dictionary)):
        if ("select"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            for j in range(0,len(tmp)):
                if (j==0):
                    result = result+ "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
                if (j>0):
                    result = result + ", " + "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
        elif ("pluck"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            for j in range(0,len(tmp)):
                if (j==0):
                    result = result+ "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
                if (j>0):
                    result = result + ", " + "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
        elif ("value"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            for j in range(0,len(tmp)):
                if (j==0):
                    result = result+ "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
                if (j>0):
                    result = result + ", " + "`"+tmp[j].replace("'","").replace('"','').strip()+"`"

        #if ("first"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
        #    tmp = get_value_in_parentheses(dictionary.values()[i])
        #    for j in range(0,len(tmp)):
        #        if (j==0):
        #            result = result+ "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
        #        if (j>0):
        #            result = result + ", " + "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
        #    result = "first(" + result + ")"
        if ("distinct"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            for j in range(0,len(tmp)):
                if (j==0):
                    result = result+ "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
                if (j>0):
                    result = result + ", " + "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
            result = "distinct " + result 
        elif ("min"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            for j in range(0,len(tmp)):
                if (j==0):
                    result = result+ "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
                if (j>0):
                    result = result + ", " + "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
            if (result== "``"):
                result = "*"
            result = "min("+ result +") as aggregate"
        elif ("count"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            for j in range(0,len(tmp)):
                if (j==0):
                    result = result+ "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
                if (j>0):
                    result = result + ", " + "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
            if (result== "``"):
                result = "*"         
            result = "count("+ result +") as aggregate"
        elif ("max"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            for j in range(0,len(tmp)):
                if (j==0):
                    result = result+ "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
                if (j>0):
                    result = result + ", " + "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
            if (result== "``"):
                result = "*"
            result = "max("+ result +") as aggregate"
        elif ("sum"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            for j in range(0,len(tmp)):
                if (j==0):
                    result = result+ "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
                if (j>0):
                    result = result + ", " + "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
            if (result== "``"):
                result = "*"
            result = "sum("+ result +") as aggregate"
        elif ("avg"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            for j in range(0,len(tmp)):
                if (j==0):
                    result = result+ "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
                if (j>0):
                    result = result + ", " + "`"+tmp[j].replace("'","").replace('"','').strip()+"`"
            if (result== "``"):
                result = "*"
            result = "avg("+ result +") as aggregate"

    if result == "":
        result = "*"
    return result

## Get limit
def get_limit_for_sql(dictionary):
    result = ""
    for i in range(0,len(dictionary)):
        if ("paginate"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            for j in range(0,len(tmp)):
                if (j==0):
                    result =  result+"'"+tmp[j]+"'"
                if (j>0):
                    result = result + ", " + "'"+tmp[j]+"'"
        elif ("limit"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            for j in range(0,len(tmp)):
                if (j==0):
                    result =  result+"'"+tmp[j]+"'"
                if (j>0):
                    result = result + ", " +"'"+tmp[j]+"'"
        elif ("simplepaginate"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            for j in range(0,len(tmp)):
                if (j==0):
                    result =  result+"'"+tmp[j]+"'"
                if (j>0):
                    result = result + ", " + "'"+tmp[j]+"'"
        elif ("first"+"["+str(i)+"]" == dictionary.keys()[i].strip().lower()):
            tmp = get_value_in_parentheses(dictionary.values()[i])
            for j in range(0,len(tmp)):
                if (j==0):
                    result =  result+"'"+"1"+"'"
                if (j>0):
                    result = result + "," + tmp[j]
    if result == "":
        result = None
    return result

            
            
            




def make_query_to_sql(file_to_read):
    lines = library.read_files(file_to_read)
    result = []
    for i in lines:
#string="(new tables)->where('lala',3)->orwhere('lili',4)->where('lala',5)->groupby('lele')->orderby('fack','asc')->orderby('dcm',desc)->first()"
        if ("public function"in i):
            #result.append(i)
            continue
        dictionary= string_array_dictionary(i)
        if dictionary == "":
            continue
        query_type = get_query_type(dictionary)
        option_query = get_option_of_query(dictionary)
        table_name = get_table_name_for_sql(i)
        if table_name == "":
            continue
        condition = get_condition_for_sql(dictionary)
        groupby = get_groupby_for_sql(dictionary)
        orderby = get_orderby_for_sql(dictionary)
        limit = get_limit_for_sql(dictionary)
#print split_string_to_key_and_value(string,3)
#print string_array_dictionary(string)
        tmp=query(query_type,option_query,table_name,condition,groupby,orderby,limit)
        tmp = tmp.complete_query()
        print tmp
        tmp = tmp.replace("`","\`").strip()
        tmp = replace_variable_value_to_questionaire(tmp)
        if (tmp.strip()[-1]!=")" and tmp.strip()[-1] != "`"):
            tmp = "(?i)(^"+tmp.strip()+"$)"
        else:
            tmp = "(?i)(^"+tmp.strip()+"\B$)"
        result.append(tmp)
        
    return result


#####################
def laravel_to_sql():
    directory_to_read = "sub_folder/last_controller"
    directory_to_write = "sub_folder/query_to_sql/"
    controller_listfile = library.scan_directory(directory_to_read)
    for files in controller_listfile:
        list=[]
        f = open(files,"r")
        file_to_write = directory_to_write +os.path.basename(f.name).lower().replace("txt","txt")
        list = make_query_to_sql(files)
        library.write_files(file_to_write,list)

