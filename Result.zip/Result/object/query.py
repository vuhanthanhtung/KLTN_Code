class query:
    def __init__(self, query_type,option_query, table_name, condition=None, groupby=None, orderby=None, limit=None, join=None):
        self.query_type = query_type
        self.option_query= option_query
        self.table_name = table_name
        self.condition = condition
        self.groupby = groupby
        self.orderby = orderby
        self.limit = limit
        self.join = join
    def showQuery(self):
        print("Query_type:" ,self.query_type)
        print("option_query:", self.option_query)
        print("Table:" ,self.table_name)
        print("condition:" ,self.condition)
        print("groupby: ", self.groupby)
        print("orderby: ", self.orderby)
        print("limit:" , self.limit)
        print("join:" , self.join)
    def complete_query(self):
        result = ""
        if (self.query_type!=None):
            result = self.query_type
        if ( self.option_query!=None):
            result = result +" "+ self.option_query
        if (self.table_name !=None):
            result = result + " from " + "`"+self.table_name+"`"
        if (self.condition != None):
            result = result + " where " + self.condition
        if (self.groupby != None):
            result = result + " group by " + self.groupby
        if (self.orderby !=None):
            result = result + " order by " + self.orderby
        if (self.limit != None):
            result = result + " limit " + self.limit
        return result

#apt = query("select","lala","condition",None,"lele")
#apt.showQuery()

