from query import query

###### get select/insert/udpate
def get_query_for_sql(string):
    result=""
    ##### select 
    if ("get" or "first" or "all") in string:
        result = "select"
    return result
###### get table name
def get_table_name_for_sql(string):
    result=""
    if ("::" in string):
        result=string.split("::")[0]
        print result
        return result
    if ("new" in string):
        result=string.split("new")[1]
        result=result.split(")->")[0]
        return result
    return result

###### get condition 
def get_value_in_parentheses(string):
    result = []
    string=string.replace("(","")
    string=string.replace(")","")
    array=string.split(",")
    result=array
    return result

def get_condition_for_sql(string):
    result=[]
    if ("where" in string):
        array = string.split("where")
        #if len(array) > 2:
        #    print "we will process later"
        #if len(array) <= 2:
        for i in range(1, len(array)):
            tmp=array[i].split("->")[0]
            array_value=get_value_in_parentheses(tmp)
            if len(array_value) >2 :
                tmp_value = array_value[0] + array_value[1] + array_value[2]
            if len(array_value) <= 2:
                tmp_value = array_value[0] + "=" + array_value[1]
            result.append(tmp_value)
    return result


### get option_query: example: distinct
def get_option_or_value_query_for_sql(string):
    result=None
    if ("distinct" in string):
        result="unique"
    if ("select" in string.lower()):
        tmp = string.split("select")
        tmp = tmp.split("->")
        array_value = get_value_in_parentheses(tmp)
        result = array_value
    return result

#### get option_condition
def get_option_condition_for_sql(string):
    result=[]
    if ("where" in string):
        array=string.split("where")
        if len(array)==2:
            return None
        for i in range(1,len(array)-1):
            if ("or" in array[i].lower()):
                result.append("or")
            else:
                result.append("and")
        return result

#### get groupby
def get_groupby_for_sql(string):
    result=None
    if ("groupby" in string.lower()):
        tmp = string.lower().split("groupby")[1]
        tmp = tmp.split("->")[0]
        array_value = get_value_in_parentheses(tmp)
        result = array_value
    return result

##### get orderby
def get_orderby_for_sql(string):
    result=[]
    if ("orderby" in string.lower()):
        array=string.lower().split("orderby")
        for i in range(1,len(array)):
            tmp=array[i].split("->")[0]
            array_value=get_value_in_parentheses(tmp)
            tmp_value = array_value[0] + "," + array_value[1]
            result.append(tmp_value)
    if result == "":
        result= None
    return result

        





string="(new abc)->where('lala',>,2)->orwhere('lele',3)->groupBy('fuckin','dcm')->orderby('lala',desc)->orderby('kaka',asc)->distinct()->get()"
query_name=get_query_for_sql(string)
table_name=get_table_name_for_sql(string)
condition=get_condition_for_sql(string)
option_query=get_option_query_for_sql(string)
option_condition=get_option_condition_for_sql(string)
groupby=get_groupby_for_sql(string)
orderby=get_orderby_for_sql(string)

abc=query(query_name,table_name,condition,option_query,option_condition,groupby,orderby)
abc.showQuery()
