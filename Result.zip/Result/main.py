import library
import model
import controller
import route
import model_function
import get_real_table_name
import model_function_query
import inside_link
import outside_link
import sys
sys.path.append("object/")
import laravel_to_sql_v2
import route_controller
import scan
import argparse

################ARG PARSER#################
parser = argparse.ArgumentParser(description='This tools wwill help you to Get all the query from your web application source code')
parser.add_argument('-s',action="store",dest='path_to_web_app', help='Your web application source code')
parser.add_argument('-e',action="store",dest="Framework", help='Framework of your website. Now we have supported Laravel and Pure PHP', choices=['Laravel','Pure PHP'], default='Laravel')









###################################
args = parser.parse_args()
path_to_web_app=args.path_to_web_app
Framework=args.Framework

if (Framework == "Laravel"):
   # path_to_web_app="/var/www/html/web"
    path_to_controller=path_to_web_app+"/app/Http/Controllers"
    path_to_model=path_to_web_app+"/app"
    path_to_route=path_to_web_app+"/routes"
    model.model(path_to_web_app)
    route.route(path_to_route)
    model_function.model_function(path_to_web_app)
    get_real_table_name.get_real_table_name(path_to_web_app)
    controller.controller(path_to_controller)
    model_function_query.model_function_query(path_to_model)
    inside_link.inside_link()
    outside_link.outside_link()
    laravel_to_sql_v2.laravel_to_sql()
#route_controller.route_controller()

    file="sub_folder/query_to_sql/default.txt"
    list=["set names (.+) collate (.+)",
        "set session sql_mode=(.+)",
        "use \`(.+)\`;"
    ]
    library.write_files(file,list)
else:
    scan.Scan_PHP(path_to_web_app)
