import library
def get_real_table_name(directory):
    #directory = "/root/laravel-ecommerce"
    file = "sub_folder/table.txt"
    list = []
    flag = 0
    listfile = library.scan_directory(directory)

    for files in listfile:
            model_name = ""
            lines = library.read_files(files)
            model_name, flag = library.get_model_name(lines)
            if flag == 1:
                    table_name = library.get_real_table_name(files)
                    if (table_name == ""):
                        table_name = model_name+"s"
                    result = model_name + "::" + table_name
                    list.append(result)
    library.write_files(file,list)

