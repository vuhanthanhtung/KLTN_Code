import library
import os
def model_function_query(directory):
#directory="/root/laravel-ecommerce/app/Models"
    model_listfile = library.scan_directory(directory)
    model_name = ""
    flag = 0
    list = []
    list_string = []
    for files in model_listfile:
	list = []
	f = open(files, "r")
	lines = f.readlines()
	name_file = "sub_folder/model/" + os.path.basename(f.name).lower().replace("php", "txt")
	model_name, flag = library.get_model_name(lines)
	if flag == 1:
		list_string = library.format(lines)
		for string in list_string:
	                result = ""
			string = library.replace(string, model_name)
	                result = library.get_function(string)
	                if (result != ""):
	                        list.append(result)
	                result = library.get_query(string)
	                result = library.format_string(result)
	                for z in result:
	                    	if (z != ""):
	                        	list.append(z)
        library.write_files(name_file, list)


