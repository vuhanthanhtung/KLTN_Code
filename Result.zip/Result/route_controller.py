import library

def route_controller():
    directory="sub_folder"
    files="sub_folder/route.txt"
    lines=library.read_files(files)
    for i in lines:
	url = library.get_url_from_route(i)
	controller_function_name = library.get_controller_function_name(i)
	controller_name = library.get_controller_name(controller_function_name)
	function_name = library.get_function_name(controller_function_name)
	files_1 = directory + "/query_to_sql/" + controller_name +".txt"
	files_2 = directory + "/result/" + url + ".txt"
	read_files = library.read_files(files_1)
	query = library.get_all_query_from_function(files_1, function_name)
	library.write_files_append(files_2,query)

