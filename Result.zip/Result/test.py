import library
def get_variable(string):
    result=[]
    if ("$" in string):
        tmp = string.split("$")
        if ( len(tmp)>1):
            for i in range(1,len(tmp)):
                    tmp_1=tmp[i].split("'")[0]
                    result.append(tmp_1)
    return result

def replace_variable_to_questionaire(string):
    result =""
    array = get_variable(string)
    for i in array:
        tmp = "'$"+i+"'"
        if tmp in string:
            string=string.replace(tmp,"? ")
    result = string
    return result
def get_value(string):
    result=[]
    array = string.replace("'"," ")
    array = array.replace('"',' ')
    array = library.Replace_spaces_to_1_space(array)
    array = array.split("= ")
    if (len(array)>1):
        for i in range(1,len(array)):
            tmp_1=array[i].split(" ")[0]
            result.append(tmp_1)
    return result
    



string="select * from users where username='$username'and password='password'"
a=get_value(string)
print a

