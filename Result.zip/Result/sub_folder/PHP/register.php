(?i)(^select \* from users where username = (.+)\B$)
(?i)(^insert into users\(username, email, address, phone, password \) values\((.+),(.+),(.+),(.+),(.+)\)\B$)
(?i)(^select userid from users where username=(.+)\B$)
