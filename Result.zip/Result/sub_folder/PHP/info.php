(?i)(^select \* from users where username = (.+)\B$)
