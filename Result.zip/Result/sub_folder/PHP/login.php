(?i)(^select \* from users where username=(.+) and password=(.+)\B$)
