import library
def model(directory):
    #directory = "/root/laravel-ecommerce"
    file = "sub_folder/model.txt"
    list = []
    flag = 0
    listfile = library.scan_directory(directory)

    for files in listfile:
	    model_name = ""
	    lines = library.read_files(files)
	    model_name, flag = library.get_model_name(lines)
	    if flag == 1:
		    list.append(model_name)

    library.write_files(file,list)
