import library
def model_function(directory):
#directory="/root/laravel-ecommerce/app/Models"
    	model_listfile = library.scan_directory(directory)
    	model_name = ""
    	flag = 0
    	list = []
	list_string = []
    	for files in model_listfile:
	    	lines = library.read_files(files)
	    	model_name, flag = library.get_model_name(lines)
	    	if flag == 1:
			list_string = library.format(lines)
			for string in list_string:
		    	    	result=""
		    	    	result=library.get_name_function(string)
                            	result = result.strip().split("(")[0]
		    	    	if (result != ""):
				    	kq = "(new " + model_name + ")->" + result
				    	list.append(kq)
    	file = "sub_folder/model_function.txt"
    	library.write_files(file, list)
