import library
import os
def outside_link():
    directory_to_read="sub_folder/controller"
    directory_to_write="sub_folder/last_controller/"
    controller_listfile = library.scan_directory(directory_to_read)
    for files in controller_listfile:
        list = []
        f = open(files,"r")
        file_to_write = directory_to_write + os.path.basename(f.name).lower().replace("txt","txt")
        list = library.Link(files)
        library.write_files(file_to_write,list)

