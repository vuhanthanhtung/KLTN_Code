#!/bin/bash
file="$1"
echo > $file
mysql -u admin -padmin -h127.0.0.1 -P6032 -e "SELECT sum_time FROM stats_mysql_query_digest_reset ORDER BY sum_time"
for i in {0..99..1}
do
mysql -u imba -pimba -h192.168.229.131 -P6033 -e "select * from databasefirewall.users where username='admin' and password='admin'">/dev/null 2>&1
mysql -u admin -padmin -h127.0.0.1 -P6032 -e "SELECT sum_time FROM stats_mysql_query_digest_reset ORDER BY sum_time"| grep -v "sum_time" | grep -v -w "0" >> $file
mysql -u admin -padmin -h127.0.0.1 -P6032 -e "load mysql query rules to runtime" 
#>/dev/null 2>&1


#mysql -u imba -pimba -h192.168.229.131 -P6033 -e "RESET QUERY CACHE" >/dev/null 2>&1
#mysql -u imba -pimba -h192.168.229.131 -P6033 -e "FLUSH QUERY CACHE" >/dev/null 2>&1

sleep 2
done

