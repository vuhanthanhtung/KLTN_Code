#!/bin/bash
query="(?i)(^select \* from users where username=(.+) and password=(.+)\B$)"
i=10000

mysql -u admin -padmin -h127.0.0.1 -P6032 -e "insert into mysql_query_rules (rule_id,active,username,match_digest,destination_hostgroup,apply) values ($i,1,'imba','$query',1,1);" > /dev/null 2>&1
mysql -u admin -padmin -h127.0.0.1 -P6032 -e "load mysql query rules to runtime;"
