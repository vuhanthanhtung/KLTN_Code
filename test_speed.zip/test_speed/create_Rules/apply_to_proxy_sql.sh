#!/bin/bash
#query="(?i)(^select \* from \`information\` where \`isStudent\` = (.+) and \`Number\` < (.+) order by \`id\` desc limit (.+)\B$)"
Number_of_rules=$1

mysql -u admin -padmin -h127.0.0.1 -P6032 -e "insert into mysql_query_rules (rule_id,active,username,match_digest,destination_hostgroup,apply,error_msg) values (10000,1,'imba','.',1,1,'Not Allowed');"

for i in {1..9999..1}
do
query="(?i)(^select \* from \`information"$i"\` where \`isStudent\` = (.+) and \`Number\` < (.+) order by \`id\` desc limit (.+)\B$)"
mysql -u admin -padmin -h127.0.0.1 -P6032 -e "insert into mysql_query_rules (rule_id,active,username,match_digest,destination_hostgroup,apply) values ($i,1,'imba','$query',1,1);" > /dev/null 2>&1
done
mysql -u admin -padmin -h127.0.0.1 -P6032 -e "load mysql query rules to runtime;"
