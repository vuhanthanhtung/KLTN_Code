def cal(file):
	f=open(file,"r").readlines()
	result=0
	for i in f:
		if (i == ""):
			continue
		num = int(i)
		result = result + num
	result = result/100
	return result
file="result/rules10000.txt"
print cal(file)	
