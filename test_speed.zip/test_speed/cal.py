import math
def mean(data):
    return sum(data)/len(data)

def variance(data):
    mu = mean(data)
    return sum([(point-mu)**2 for point in data])/len(data)

def stddev(data): # standard deviation
    return math.sqrt(variance(data))

def cal(file):
	f=open(file,"r").readlines()
	result=0
	array =[]
	for i in f:
		array.append(int(i))
	result = stddev(array)
	
	return result

file="result/rules.txt"

print cal(file)	
